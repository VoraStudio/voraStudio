# 📽️ DIAPOSITIVA 10 — Protecció contra abús

---

## Rate Limiting (rate_limiter.yaml)

| Limitador | Política | Límit | On s'aplica |
|-----------|----------|-------|-------------|
| `api_movie_search` | Token bucket | **60/min** (1/seg) | `MovieApiController::buscar()` → per usuari |
| `api_register` | Sliding window | **10/hora** | `UserApiController::register()` → per IP |

**Login throttling (security.yaml):** 5 intents/minut als firewalls `login` (API JWT) i `main` (admin).

```php
$limiter = $apiMovieSearchLimiter->create($user->getId());
if (false === $limiter->consume(1)->isAccepted()) {
    return $this->json(['error' => 'Espera un minut'], 429);
}
```

---

## Honeypot Anti-Bot

Al formulari de **registre** (`UserApiController`):

```php
// Camp ocult al HTML: email_verification_field
if (!empty($data['email_verification_field'])) {
    // Bot creu que ha funcionat → retornem 201 fals
    return $this->json(['message' => 'Usuari registrat'], 201);
}
```

> Un bot omple tots els camps visibles → cau al honeypot → rep un 200/201 fals. L'usuari real no veu el camp (CSS ocult) i el deixa buit → passa de llarg.

---

## Argon2id + CSRF

**Argon2id** per a contrasenyes (`security.yaml`):

```yaml
password_hashers:
    algorithm: argon2id
    time_cost: 4
    memory_cost: 65536
```

**CSRF** automàtic als formularis del panell admin (`enable_csrf: true`).
