# 📽️ DIAPOSITIVA 3 — Arquitectura del sistema

---

**4 CAPAS:**

```
LANDING (estàtica) → FRONTEND Vue 3 (SPA + Pinia) → BACKEND Symfony 7.4 (API REST) → MySQL + Doctrine
```

---

## ① Landing — Aparador estàtic
HTML5 + CSS3 + Bootstrap + OwlCarousel + WOW.js. Sense BD, sense backend. Porta d'entrada.

## ② Frontend — SPA Reactiva (Vue 3 + Vite 7)

**2 stores Pinia (Composition API):**

| Store | Estat real | Accions principals |
|-------|-----------|-------------------|
| **user.js** | `user`, `isLoading` | `login()` → guarda token a localStorage + `fetchUser()`. `logout()` → `removeItem('token')`. Getters: `username`, `generoFavorito`, `favoritos`, `isAuthenticated` |
| **catalog.js** | `allMovies`, `generos`, `isLoaded`, `novedades`, `populares`, `feedPersonalizado` | `loadCatalogData()` → GET `/api/home-data` + cache 60min. `searchMovies()`, `getMoviesByGenre()`, `getMovieDetail()` |

> Token JWT només a localStorage. L'interceptor Axios el llegeix i l'adjunta a cada petició.

## ③ Backend — API REST + Proxy Segur (Symfony 7.4 + PHP 8.3)

| Servei | Funció |
|--------|--------|
| **TmdbService** | Fetch TMDB (HttpClient + Cache) |
| **MovieSyncService** | Sincronització catàleg TMDB → BD |
| **AiService** | Motor RAG: busca a BD → Groq API (llama-3.3-70b) |
| **FileService** | Uploads d'imatges |

**🔐 Punt fort:** TMDB i Groq només desde backend. Frontend **no té accés** a API keys.

## ④ Base de Dades — MySQL + Doctrine ORM

**5 entitats relacionals:**

```
USUARI ──1:N──▶ PELICULA (propietari)
USUARI ──1:N──▶ RESSENYA ──N:1──▶ PELICULA
PELICULA ──M:N──▶ GENERE
PELICULA ──M:N──▶ ACTOR
```

