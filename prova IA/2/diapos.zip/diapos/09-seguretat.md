# 📽️ DIAPOSITIVA 9 — Seguretat i Validació

---

## JWT — 2 capes (repàs slide 6)

| Capa | Quan |
|------|------|
| **Route guard (beforeEach)** | Al navegar entre rutes → token expirat? redirigeix a login |
| **Response interceptor (Axios)** | A cada resposta 401 → neteja token i redirigeix |

---

## Control d'accés (security.yaml)

L'ordre **importa**: Symfony aplica la **primera coincidència**.

```yaml
access_control:
    - { path: ^/api/?$, roles: PUBLIC_ACCESS }           # Només /api i /api/ (amb $ final)
    - { path: ^/api/login, roles: PUBLIC_ACCESS }        # Login
    - { path: ^/api/register, roles: PUBLIC_ACCESS }     # Registre
    - { path: ^/api, roles: IS_AUTHENTICATED_FULLY }     # Tota la resta d'API
    - { path: ^/login, roles: PUBLIC_ACCESS }            # Panel admin login
    - { path: ^/logout, roles: PUBLIC_ACCESS }
    - { path: ^/admin, roles: ROLE_ADMIN }               # Panel admin
```

**Per què aquest ordre?** Si poséssim `^/api` (IS_AUTHENTICATED_FULLY) abans que `^/api/login` (PUBLIC_ACCESS), el login demanaria token i ningú podria autenticar-se.

| Rol | Accés |
|-----|-------|
| **PUBLIC_ACCESS** | Login, registre, arrel API |
| **IS_AUTHENTICATED_FULLY** | Usuari loguejat (JWT vàlid) |
| **ROLE_USER** | Navegar, valorar, xatejar amb IA |
| **ROLE_ADMIN** | Tot l'anterior + panell admin (`/admin`) |

**Jerarquia:** `ROLE_ADMIN: ROLE_USER` → admin hereta permisos de user.

**Doble capa:** cada controller afegeix la seva restricció amb `#[IsGranted]` (ex: `AiController` requereix `ROLE_USER`). Així tenim **`access_control` global + restricció per controller**.

---

## Validació amb Constraints

**Usuari:**

| Camp | Constraints |
|------|------------|
| `username` | `NotBlank`, `Length(3-30)`, `Regex(/^[a-zA-Z0-9._-]+$/)`, `UniqueEntity` |
| `genere` | `NotBlank`, `Choice(20 gèneres)` |
| `email` | `Email` |
| `avatarFile` | `File(maxSize: 2M, mimeTypes: jpg/png/webp)` |

**Pelicules:**

| Mètode | Què fa |
|--------|--------|
| `validateTitols()` (Callback) | Obliga almenys un títol (Es, Ca o En) |

**Contrasenyes:** xifrades amb **Argon2id** (`time_cost: 4`, `memory_cost: 65536`).
