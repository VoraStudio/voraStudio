# 📽️ DIAPOSITIVA 5 — Pinia — Gestor d'Estat

---

**2 stores amb Composition API (ref / computed):**

| Store | Què controla |
|-------|-------------|
| **user.js** | Autenticació, perfil, gènere favorit, favorits |
| **catalog.js** | Catàleg, cerca, cache local, seccions del Home |

**Com funciona la reactivitat:**

```javascript
// user.js — computed recalcula automàticament
const generoFavorito = computed(() => user.value?.genere)

// catalog.js — watch dispara efectes secundaris
watch(() => userStore.generoFavorito, (nouGenere) => {
  recargarFeedPersonalizado()  // Actualitza feedPersonalizado.value
})
```

**Cadena real:**

```
Usuari canvia gènere favorit
  → computed generoFavorito es recalcula
    → watch ho detecta → recargarFeedPersonalizado()
      → feedPersonalizado.value = response.data
        → Vue re-renderitza les vistes que consumeixen feedPersonalizado
```

> Les vistes **no canvien res** — només reaccionen perquè Vue 3 detecta que el state que fan servir ha mutat. Automàtic.

**Per què és útil:**

- Qualsevol component crida `useUserStore()` o `useCatalogStore()` i ja està subscrit
- Cache local (60min) + flag `isLoaded` eviten peticions duplicades
- Token JWT només a localStorage — l'interceptor d'Axios el gestiona
