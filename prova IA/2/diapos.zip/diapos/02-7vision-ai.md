# 📽️ DIAPOSITIVA 2 — 7Vision AI

---

## 1. Petición POST al backend

**Archivo:** `src/Controller/Api/AiController.php`

El frontend envía `POST /api/ai/chat` con:

```json
{ "prompt": "recomiéndame películas de ciencia ficción" }
```

El controlador:

1. **Valida** que `prompt` no supere 200 caracteres (abuso de tokens)
2. **Delega** a `AiService::getRecommendation($prompt, $user)`

Requiere autenticación JWT (`#[IsGranted('ROLE_USER')]`). Sin token → 401.

---

## 2. Búsqueda invisible (RAG local)

**Archivo:** `src/Service/AiService.php` — método `getRecommendation()`

### 2.1 findForAiContext()

**Archivo:** `src/Repository/PeliculesRepository.php` (líneas 90–117)

```php
$words = explode(' ', $query);
foreach ($words as $word) {
    if (strlen($word) < 3) continue; // Ignora palabras cortas (de, la, el, un)

    $qb->andWhere("p.titolEs LIKE :q OR p.titolCa LIKE :q 
                   OR g.nomEs LIKE :q OR a.nom LIKE :q");
}
```

Separa la query palabra por palabra, ignora palabras de **menos de 3 caracteres**, y busca coincidencias en **4 campos simultáneamente**:

| Campo | Entidad | Ejemplo |
|-------|---------|---------|
| `titolEs` | Pelicules | "Avatar" |
| `titolCa` | Pelicules | "Avatar" |
| `nomEs` | Genere | "Ciencia ficción" |
| `nom` | Actor | "Sam Worthington" |

Ordena por `popularitat DESC`, límite 45 resultados.

### 2.2 Fallback

Si `findForAiContext()` no encuentra nada (ej: "hola"), se obtienen las **45 películas más populares** como contexto de respaldo:

```php
if (empty($relevantMovies)) {
    $relevantMovies = $this->movieRepository->findBy([], ['popularitat' => 'DESC'], 45);
}
```

---

## 3. Post-procesado en AiService

### 3.1 Deduplicación

Se filtran duplicados por título (case-insensitive):

```php
$titlesSeen = [];
foreach ($relevantMovies as $m) {
    $title = strtolower(trim($m->getTitolEs() ?? ''));
    if ($title && !isset($titlesSeen[$title])) {
        $titlesSeen[$title] = true;
        $uniqueMovies[] = $m;
    }
}
```

### 3.2 Enriquecimiento de datos

De cada película se extrae:

| Dato | Método | Ejemplo |
|------|--------|---------|
| Año | `getDataEstrena()->format('Y')` | 2009 |
| Géneros | `getGeneres()` → `getNomEs()` | Ciencia ficción, Aventura |
| Actores (top 3) | `getActors()->slice(0, 3)` → `getNom()` | Sam Worthington, Zoe Saldana |

### 3.3 Contexto de usuario (si logueado)

```php
if ($user) {
    $username = sanitize($user->getUsername());
    $favs = $user->getFavorits()->slice(0, 5);  // Top 5 favoritos
    $userContext = "Hablas con '{$username}'. 
                   Su género favorito es: {$user->getGenere()}. 
                   Sus favoritos: Dune, Inception...";
}
```

Sanitización contra prompt injection: `strip_tags()` + `preg_replace('/[^a-zA-Z0-9._-]/', '')`.

---

## 4. Llamada a Groq API

**Modelo:** `llama-3.3-70b-versatile`

Se construye un **system prompt** masivo que incluye:

```
System prompt:
  - Rol: Vision-AI, asistente de 7Vision
  - Contexto del usuario (género favorito, favoritos)
  - Catálogo completo: 45 películas con [ID:N], año, género, reparto
  - Reglas estrictas:
    • No inventar datos fuera del catálogo
    • No spoilers
    • Responder en el idioma del usuario
    • Formato <b> para títulos, <i> para actores
    • Máximo 3 frases
    • ASSET_ID: [ID:numero] al final

User message:
  - El prompt original del usuario
```

Parámetros:

| Parámetro | Valor |
|-----------|-------|
| `temperature` | 0.7 |
| `presence_penalty` | 0.6 |
| `max_tokens` | 500 |

**Archivo:** `src/Service/AiService.php` — líneas 65–93

---

## 5. Frontend: VisionChat.vue

**Archivo:** `src/components/VisionChat.vue`

### Recepción de la respuesta

```php
// Backend devuelve
{ "status": "SUCCESS", "answer": "Te recomiendo <b>Avatar</b>... ASSET_ID: [ID:1]" }
```

### Parseo de `[ID:N]`

```javascript
const parseAiResponse = (text) => {
    const regex = /\[ID:\s*(\d+)\]/gi;
    // Extrae todos los IDs numéricos
    // Limpia el texto eliminando ASSET_ID: y [ID:N]
    return { cleanText, movieIds: [1, 5, 12] };
};
```

### Renderizado

- **Texto** con `v-html` → las etiquetas `<b>` e `<i>` del system prompt se renderizan
- **Tarjetas de película** → cada `[ID:N]` se convierte en una card cliqueable con:
  - Póster (`getImageUrl(movie.poster)`)
  - Título
  - Enlace "Ver"

```html
<div class="msg-content" v-html="msg.text"></div>

<div v-for="id in msg.movieIds" class="ai-movie-card-mini" @click="openMovie(id)">
  <img :src="getImageUrl(getMovieData(id).poster)" />
  <span>{{ getMovieData(id).titolEs }}</span>
  <span>Ver →</span>
</div>
```

Las `movies` se reciben como prop desde `Navbar.vue` (`catalogStore.allMovies`).

### Navegación al hacer clic

```javascript
const openMovie = (id) => {
    isOpen.value = false;
    router.push({ path: '/', query: { movie: id, t: Date.now() } });
};
```

Cierra el chat y abre el modal de detalle en Home.

---

## 6. Tests

**Archivo:** `tests/Api/AiApiTest.php`

| Test | Lo que comprueba |
|------|-------------------|
| `testAiChatUnauthorized` | Sin token → 401 |
| `testAiChatEmptyPrompt` | Prompt vacío → 400 "prompt buit" |
| `testAiChatTooLongPrompt` | 250 caracteres → 400 "prompt massa llarg" |

---

## 7. Resumen del flujo completo

```
Usuario escribe "recomiéndame acción" en VisionChat
  → POST /api/ai/chat { prompt: "recomiéndame acción" }
    → AiController valida ≤200 chars
      → AiService::getRecommendation()
        1. findForAiContext("recomiéndame acción", 45)
           → busca en títulos, géneros, actores
           → ignora palabras < 3 chars ("me")
        2. ¿Vacío? → fallback a populares
        3. Deduplica por título
        4. Enriquece: año, género, actores
        5. Si logueado: nombre, género fav, top 5 favoritos
        6. Construye system prompt con catálogo + reglas
        7. POST a Groq API → llama-3.3-70b-versatile
        8. Devuelve respuesta con ASSET_ID: [ID:N]
      ← { status: "SUCCESS", answer: "..." }
    → VisionChat parsea [ID:N] → muestra texto + tarjetas
    → Usuario clica tarjeta → modal de detalle
```
