# 📽️ DIAPOSITIVA 8 — Cache al Frontend

---

**Doble capa de cache a catalog.js:**

```
loadCatalogData()
  → isLoaded? (sessió) → si, retorna cache en memòria
  → localCache.get('home_data')? (1h) → si, actualitza estat i retorna
  → GET /api/home-data → Backend → MySQL
  → localCache.set('home_data', data, 60)
  → isLoaded = true
```

| Capa | Àmbit | TTL | Què evita |
|------|-------|-----|-----------|
| `isLoaded` | Memòria (sessió) | Dura la sessió | Peticions duplicades navegant entre vistes |
| `localCache` | localStorage | 60 minuts | Peticions repetides entre sessions |

**El localCache real (fora de la store, a nivell de mòdul):**

```javascript
const localCache = {
  get(key) {
    const { data, expiry } = JSON.parse(localStorage.getItem(key))
    if (expiry && Date.now() > expiry) {
      localStorage.removeItem(key)
      return null           // ← expirat
    }
    return data
  },
  set(key, data, ttlMinutes = 60) {
    const expiry = Date.now() + (ttlMinutes * 60 * 1000)
    localStorage.setItem(key, JSON.stringify({ data, expiry }))
  }
}
```

> **Fallback silenciós:** tot dins de try/catch. Si localStorage està ple o corrupte, l'app segueix funcionant sense cache.
