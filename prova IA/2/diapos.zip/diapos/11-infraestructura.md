# 📽️ DIAPOSITIVA 11 — Infraestructura i Desplegament

**Glossari AWS + GitHub Actions:**

| Servei | Significat | Què fa |
|--------|-----------|--------|
| **EC2** | Elastic Compute Cloud | Màquina virtual al núvol. Servidor tradicional on instal·lem Apache, PHP, Node, etc. |
| **ECS** | Elastic Container Service | Orquestració de contenidors Docker. Amb **Fargate** no cal gestionar servidors — AWS executa els contenidors directament |
| **ECR** | Elastic Container Registry | Repositori privat d'imatges Docker a AWS. Hi pugem les imatges (frontend, backend) i ECS les baixa per executar-les |
| **ALB** | Application Load Balancer | Punt d'entrada del trànsit. Rep les peticions i les redirigeix al servei corresponent (frontend o backend) segons el path de la URL |
| **S3** | Simple Storage Service | Emmagatzematge d'objectes. Per a fitxers estàtics (landing page, imatges, etc.) sense servidor |
| **Task Definition** | — | Plantilla JSON que defineix com s'executa un contenidor a ECS: imatge Docker, ports, CPU, memòria, variables d'entorn |
| **Auto Scaling Group** | — | Grup d'instàncies EC2 que s'escala automàticament (amunt/avall) segons mètriques com % CPU. Per a ECS Fargate l'escalat es configura directament al servei |
| **Runner** | — | Màquina virtual temporal de **GitHub Actions** on s'executen els workflows: compilar codi, construir Docker, sincronitzar S3, etc. Es destrueix en acabar |

---

## Landing Page — S3

- Allotjament estàtic a **AWS S3**
- GitHub Actions: push → `aws s3 sync . s3://BUCKET --delete`
- Sense cost per petició, latència mínima global
- Condicional: main → bucket PROD, develop → bucket DEV

---

## Frontend + Backend — DEV (EC2)

| | Frontend | Backend |
|--|----------|---------|
| Servidor | **EC2** | **EC2** |
| Deploy | GitHub Actions: `npm build` → SCP a `/var/www/frontend/dist` | GitHub Actions: `rsync` + post-deploy (cache clear, migrations) |
| Enfoc | Lleugeresa, desplegament ràpid, entorn controlat | |

---

## Frontend + Backend — PROD (ECS Fargate + ALB)

- **Docker multi-stage**: build → imatge lleugera a ECR
- **ECS Fargate**: serverless, sense gestionar servidors
- **ALB**: balanceja el trànsit entre frontend i backend segons el path de la URL

---

## Auto-escalat (ECS Service Auto Scaling)

- **Horitzontal**: 1 a 4 contenidors segons % CPU
- **ECS** distribueix les tasks (contenidors) automàticament
- **Vertical**: augmentar recursos per task (CPU/memòria) si cal
- `--force-new-deployment` → rolling update sense downtime (Blue/Green)

---

## Base de Dades — RDS MySQL

- **RDS MySQL** aïllada, sense accés directe des d'internet
- Security group: `rds-sg` → **port 3306** només des d'ECS
- 3 capes de security groups:
  ```
  alb-sg (80/443 des d'internet) → ecs-sg (80 només ALB) → rds-sg (3306 només ECS)
  ```

---

## Certificat SSL

- **AWS Certificate Manager (ACM)** — crea i renova automàticament
- **Let's Encrypt** — firma el certificat

---

## Condició ternària (GitHub Actions)

```yaml
TARGET_ENV: ${{ github.ref_name == 'main' && 'prod' || 'dev' }}
TARGET_HOST: ${{ github.ref_name == 'main' && vars.EC2_HOST_PROD || vars.EC2_HOST_DEV }}
```

Un sol workflow per branch: **main → PROD** (ECS), **develop → DEV** (EC2).
