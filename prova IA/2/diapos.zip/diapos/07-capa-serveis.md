# 📽️ DIAPOSITIVA 7 — Capa de Serveis

---

**Patró: Controlador prim → Servei amb la lògica**

| Servei | Responsabilitat |
|--------|----------------|
| **TmdbService** | Connexió a TMDB API (HttpClient + Cache). Retorna pel·lícules, pòsters, actors, sinopsis, gèneres |
| **MovieSyncService** | Sincronitza TMDB → BD local. Decidiu si cerca a BD o API. **2 fases**: `crearPeliculaLigera()` (cards) + `enriquecerPelicula()` (modal detall). Deduplica per `tmdbId` |
| **AiService** | Motor RAG: busca context a BD → envia a Groq API (llama-3.3-70b). Injecta **context d'usuari** (nom, gènere favorit, favorits) al system prompt |
| **FileService** | Gestió d'uploads: avatars i pòsters. Filtres i validació d'imatges |

> Els serveis s'injecten al controlador via **autowiring** de Symfony. El controlador orquestra, el servei executa.
