# 📽️ DIAPOSITIVA 4 — Base de Dades

---

**5 entitats relacionals — MySQL + Doctrine ORM**

```
USUARI ──1:N──▶ PELICULA
   │                │
   │                ├── M:N ──▶ GENERE
   │                │
   1:N              ├── M:N ──▶ ACTOR
   │                │
   └──▶ RESSENYA ◀──┘
       1:N         1:N
```

| Entitat | Relacions | Explicació |
|---------|-----------|------------|
| **USUARI** | 1:N amb PELICULA, 1:N amb RESSENYA | Un usuari pot tenir moltes pel·lícules (propietari) i escriure moltes ressenyes |
| **PELICULA** | N:1 amb USUARI, 1:N amb RESSENYA, M:N amb GENERE, M:N amb ACTOR | Cada pel·lícula té un propietari, pot tenir moltes ressenyes i molts gèneres i actors |
| **RESSENYA** | N:1 amb USUARI, N:1 amb PELICULA | Cada ressenya pertany a un sol usuari i una sola pel·lícula |
| **GENERE** | M:N amb PELICULA | Un gènere pot classificar moltes pel·lícules i viceversa |
| **ACTOR** | M:N amb PELICULA | Un actor pot protagonitzar moltes pel·lícules i viceversa |
