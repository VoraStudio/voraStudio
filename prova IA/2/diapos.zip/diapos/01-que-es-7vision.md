# 📽️ DIAPOSITIVA 1 — ¿Qué es 7Vision?

---

## 🎯 Qué hace

7Vision es una plataforma de catálogo cinematográfico con recomendaciones por IA. Los usuarios pueden buscar películas, ver detalles, escribir reseñas y recibir recomendaciones personalizadas.

---

## 🔍 Búsqueda de películas (híbrida)

El flujo de búsqueda es **local primero, TMDB después**:

```
Usuario escribe → BD local → ¿suficientes resultados? → Sí → devuelve
                                                    → No → TMDB → guarda en BD → devuelve
```

**Archivo:** `src/Service/MovieSyncService.php` — método `buscarYSincronitzar()`

```php
$peliculesFinals = $this->repository->findByFiltres($query);

# Si hay menos de 20 en BD, busca en TMDB
if (count($peliculesFinals) < 20) {
    $dadesNoves = $this->tmdbService->buscarAmbFiltres($query);

    foreach ($dadesNoves as $data) {
        # Filtro: solo estrenadas y con puntuación
        if (empty($data['vote_average']) || $data['vote_average'] <= 0) continue;
        if (empty($data['release_date'])) continue;

        # Deduplicación: si ya existe en BD, no se crea otra vez
        $peli = $this->repository->findOneBy(['tmdbId' => $data['id']]);
        if (!$peli) {
            $peli = $this->crearPeliculaLigera($data, $generesLocals);
        }
    }
    $this->em->flush();
}
```

**Deduplicación:** busca por `tmdbId` antes de insertar — misma película nunca se duplica.

**Filtro de calidad:** solo guarda películas estrenadas con puntuación > 0. Nada de basura TMDB.

---

## 🧠 Creación en dos fases

```
1ª fase (instantánea):  crearPeliculaLigera()   → título, póster, nota
                                                      ↓
2ª fase (bajo demanda): enriquecerPelicula()     → tráiler, actores, idiomas
                                                   (solo cuando abren el modal)
```

**Archivo:** `src/Service/MovieSyncService.php`

| Fase | Método | Datos | Cuándo |
|------|--------|-------|--------|
| Ligera | `crearPeliculaLigera()` | título, póster, nota, género | En la búsqueda |
| Completa | `enriquecerPelicula()` | tráiler YouTube, 5 actores, 3 idiomas | Al abrir detalle |

---

## 📦 Controlador que lo expone

**Archivo:** `src/Controller/Api/MovieApiController.php`

| Endpoint | Método | Qué hace |
|----------|--------|----------|
| `GET /api/pelicules/buscar?q=...` | `buscar()` | Búsqueda híbrida (BD + TMDB) |
| `GET /api/pelicules/{id}` | `show()` | Detalle con enriquecimiento lazy |
| `GET /api/pelicules/by-tmdb/{tmdbId}` | `showByTmdb()` | Detalle por ID de TMDB |
