# 📽️ DIAPOS — Diapositivas del proyecto

En esta sección se recogen las diapositivas y presentaciones del proyecto 7Vision.

---

## Diapositivas disponibles

| # | Título | Descripción |
|---|--------|-------------|
| 01 | [¿Qué es 7Vision?](01-que-es-7vision.md) | Visión general, búsqueda híbrida y creación en dos fases |
| 02 | [7Vision AI](02-7vision-ai.md) | Arquitectura del chatbot RAG con Groq API |
| 03 | [Arquitectura del sistema](03-arquitectura.md) | 4 capas: Landing, Frontend (Pinia), Backend (proxy seguro), BD MySQL |
| 04 | [Base de Dades](04-base-de-dades.md) | Entitats i relacions: 1:N, M:N |
| 05 | [Pinia](05-pinia.md) | Gestor d'estat: 2 stores, reactivitat, Composition API |
| 06 | [JWT Token i Router](06-jwt-router.md) | Autenticació JWT, route guard i interceptors Axios |
| 07 | [Capa de Serveis](07-capa-serveis.md) | 4 serveis: Tmdb, MovieSync, AI, File; patró thin controller |
| 08 | [Cache](08-cache.md) | Doble capa: isLoaded (sessió) + localCache (60min), fallback silenciós |
| 09 | [Seguretat i Validació](09-seguretat.md) | Access control, jerarquia de rols, Constraints, Argon2id |
| 10 | [Protecció contra abús](10-rate-limiting.md) | Rate limiting, honeypot, login throttling, Argon2id + CSRF |
| 11 | [Infraestructura i Desplegament](11-infraestructura.md) | S3+CloudFront, EC2 dev, ECS Fargate prod, ALB, RDS, auto-escalat |
