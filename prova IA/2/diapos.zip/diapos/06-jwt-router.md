# 📽️ DIAPOSITIVA 6 — JWT Token i Router

---

## Dues capes de protecció ortogonals:

| Capa | Quan s'activa | Què fa |
|------|---------------|--------|
| **Route guard (beforeEach)** | Al CANVIAR de ruta | Si no hi ha token o està expirat → redirigeix a login abans que el component es monti |
| **Response interceptor (Axios)** | A cada RESPOSTA del backend | Si rep 401 → neteja token i redirigeix a login |

### Route guard — navegació

```javascript
// router/index.js
router.beforeEach((to) => {
  if (to.name !== "login" && to.name !== "register") {
    if (!token) return { name: "login" }

    // Decodifica JWT i comprova exp
    const payload = JSON.parse(atob(token.split('.')[1]))
    if (payload.exp * 1000 < Date.now()) {
      localStorage.removeItem("token")
      return { name: "login" }
    }
  }
})
```

### Interceptors Axios — comunicació

```javascript
// services/http.js
http.interceptors.request.use((config) => {
  const token = localStorage.getItem("token")
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

http.interceptors.response.use(
  res => res,
  error => {
    if (error.response?.status === 401) {
      localStorage.removeItem("token")
      router.push({ name: "login" })
    }
    return Promise.reject(error)
  }
)
```

> El **route guard** protegeix la navegació, l'**interceptor** protegeix les peticions. Entre les dues cobreixen tot: si expira mentre navegues → ho detecta el guard. Si expira mentre estàs quiet en una vista → ho detecta l'interceptor en la següent petició al backend.
